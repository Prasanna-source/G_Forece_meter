# G_Force_Meter_MPU6050
This is a G Force meter using mpu6050 and SSD1306 oled display. 
Range is upto 1G 
X is front 